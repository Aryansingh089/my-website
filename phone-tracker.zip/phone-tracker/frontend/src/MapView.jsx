import React, { useEffect, useRef } from "react";

export default function MapView({ location }) {
  const mapRef = useRef(null);
  const map = useRef(null);
  const marker = useRef(null);

  // Initialize map once Google Maps is fully loaded
  useEffect(() => {
    if (!window.google || !window.google.maps) {
      console.log("Google Maps not ready yet");
      return;
    }

    if (!mapRef.current) return;

    map.current = new window.google.maps.Map(mapRef.current, {
      center: { lat: 20.59, lng: 78.96 },
      zoom: 4,
    });

  }, []);

  // Update marker when location changes
  useEffect(() => {
    if (!location || !map.current) return;

    const pos = { lat: location.lat, lng: location.lng };

    if (!marker.current) {
      marker.current = new window.google.maps.Marker({
        map: map.current,
        position: pos,
      });
    } else {
      marker.current.setPosition(pos);
    }

    map.current.panTo(pos);
    map.current.setZoom(15);
  }, [location]);

  return <div ref={mapRef} style={{ width: "100%", height: "100%" }} />;
}
